"use client"

import { useState, useEffect } from "react"
import {
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Home,
  Cloud,
  Server,
  FileText,
  AlertTriangle,
  ImageIcon,
  ChevronRight,
  Zap,
  Shield,
  Database,
  User,
  Crown,
  Users,
  Sun,
  Moon,
} from "lucide-react"

const menuItems = [
  { id: "home", title: "Accueil", icon: Home },
  { id: "aws-intro", title: "AWS - Introduction", icon: Cloud, parent: "aws" },
  { id: "aws-screenshots", title: "AWS - Captures", icon: ImageIcon, parent: "aws" },
  { id: "aws-problems", title: "AWS - Problèmes", icon: AlertTriangle, parent: "aws" },
  { id: "aws-report", title: "AWS - Rapport", icon: FileText, parent: "aws" },
  { id: "proxmox-intro", title: "Proxmox - Introduction", icon: Server, parent: "proxmox" },
  { id: "proxmox-screenshots", title: "Proxmox - Captures", icon: ImageIcon, parent: "proxmox" },
  { id: "proxmox-problems", title: "Proxmox - Problèmes", icon: AlertTriangle, parent: "proxmox" },
  { id: "proxmox-report", title: "Proxmox - Rapport", icon: FileText, parent: "proxmox" },
  { id: "conclusion", title: "Conclusion", icon: ChevronRight },
]

const screenshots = [
  { id: 1, title: "Configuration AWS EC2", url: "/placeholder.svg?height=400&width=600&text=AWS+EC2+Configuration" },
  { id: 2, title: "Dashboard AWS", url: "/placeholder.svg?height=400&width=600&text=AWS+Dashboard" },
  { id: 3, title: "S3 Bucket Setup", url: "/placeholder.svg?height=400&width=600&text=S3+Bucket+Setup" },
  { id: 4, title: "Proxmox Interface", url: "/placeholder.svg?height=400&width=600&text=Proxmox+Interface" },
  { id: 5, title: "VM Creation", url: "/placeholder.svg?height=400&width=600&text=VM+Creation" },
  { id: 6, title: "Network Configuration", url: "/placeholder.svg?height=400&width=600&text=Network+Config" },
]

const problems = [
  {
    title: "Problème de connectivité AWS",
    description: "Difficulté à établir la connexion SSH avec l'instance EC2",
    solution: "Configuration des groupes de sécurité et ouverture du port 22",
    severity: "high",
  },
  {
    title: "Limitation des ressources",
    description: "Quota insuffisant pour créer plusieurs instances",
    solution: "Demande d'augmentation de quota auprès du support AWS Educate",
    severity: "medium",
  },
  {
    title: "Configuration réseau Proxmox",
    description: "Problème de routage entre les VMs",
    solution: "Reconfiguration du bridge réseau et des VLANs",
    severity: "high",
  },
]

export default function ProjectPresentation() {
  const [activeSection, setActiveSection] = useState("home")
  const [selectedImage, setSelectedImage] = useState<string | null>(null)
  const [isProfileOpen, setIsProfileOpen] = useState(false)
  const [isDarkMode, setIsDarkMode] = useState(false)
  const [visitedSections, setVisitedSections] = useState<Set<string>>(new Set())

  // Ajouter useEffect pour charger la préférence du thème
  useEffect(() => {
    const savedTheme = localStorage.getItem("theme")

    if (savedTheme === "dark") {
      setIsDarkMode(true)
      document.documentElement.classList.add("dark")
    } else {
      // Mode clair par défaut
      setIsDarkMode(false)
      document.documentElement.classList.remove("dark")
    }
  }, [])

  // Ajouter après l'useEffect existant pour le thème
  useEffect(() => {
    const savedVisitedSections = localStorage.getItem("visitedSections")
    if (savedVisitedSections) {
      setVisitedSections(new Set(JSON.parse(savedVisitedSections)))
    }
  }, [])

  // Fonction pour basculer le thème
  const toggleTheme = () => {
    const newTheme = !isDarkMode
    setIsDarkMode(newTheme)

    if (newTheme) {
      document.documentElement.classList.add("dark")
      localStorage.setItem("theme", "dark")
    } else {
      document.documentElement.classList.remove("dark")
      localStorage.setItem("theme", "light")
    }
  }

  // Ajouter après la fonction toggleTheme
  const handleSectionChange = (sectionId: string) => {
    setActiveSection(sectionId)

    // Ajouter la section aux sections visitées (sauf l'accueil)
    if (sectionId !== "home") {
      const newVisitedSections = new Set(visitedSections)
      newVisitedSections.add(sectionId)
      setVisitedSections(newVisitedSections)

      // Sauvegarder dans localStorage
      localStorage.setItem("visitedSections", JSON.stringify(Array.from(newVisitedSections)))
    }
  }

  const AppSidebar = () => (
    <Sidebar className="border-r-0">
      <SidebarHeader className="border-b border-border/40 pb-4">
        <div className="flex items-center gap-2 px-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-blue-500 to-purple-600">
            <Zap className="h-4 w-4 text-white" />
          </div>
          <div>
            <h2 className="text-sm font-semibold">Projet Cloud</h2>
            <p className="text-xs text-muted-foreground">Computing & Virtualisation</p>
          </div>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarMenu>
          {menuItems.map((item) => (
            <SidebarMenuItem key={item.id}>
              <SidebarMenuButton
                onClick={() => handleSectionChange(item.id)}
                isActive={activeSection === item.id}
                className="w-full justify-start"
              >
                <item.icon className="h-4 w-4" />
                <span>{item.title}</span>
              </SidebarMenuButton>
            </SidebarMenuItem>
          ))}
        </SidebarMenu>
      </SidebarContent>
    </Sidebar>
  )

  const ImageModal = ({ src, title, onClose }: { src: string; title: string; onClose: () => void }) => (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4" onClick={onClose}>
      <div className="relative max-h-[90vh] max-w-[90vw] overflow-hidden rounded-lg bg-white">
        <button onClick={onClose} className="absolute right-2 top-2 z-10 rounded-full bg-white/90 p-2 hover:bg-white">
          <ChevronRight className="h-4 w-4 rotate-45" />
        </button>
        <img src={src || "/placeholder.svg"} alt={title} className="h-full w-full object-contain" />
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-4">
          <h3 className="text-white font-semibold">{title}</h3>
        </div>
      </div>
    </div>
  )

  const ProgressIndicator = () => {
    const [progress, setProgress] = useState(0)

    useEffect(() => {
      const timer = setTimeout(() => setProgress(100), 500)
      return () => clearTimeout(timer)
    }, [])

    return (
      <div className="flex items-center justify-center gap-4 mb-8">
        <div className="relative">
          <svg className="w-20 h-20 transform -rotate-90" viewBox="0 0 100 100">
            <circle
              cx="50"
              cy="50"
              r="45"
              stroke="currentColor"
              strokeWidth="8"
              fill="none"
              className="text-gray-200 dark:text-gray-700"
            />
            <circle
              cx="50"
              cy="50"
              r="45"
              stroke="url(#gradient)"
              strokeWidth="8"
              fill="none"
              strokeDasharray={`${2 * Math.PI * 45}`}
              strokeDashoffset={`${2 * Math.PI * 45 * (1 - progress / 100)}`}
              className="transition-all duration-2000 ease-out"
              strokeLinecap="round"
            />
            <defs>
              <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#3B82F6" />
                <stop offset="100%" stopColor="#8B5CF6" />
              </linearGradient>
            </defs>
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              {progress}%
            </span>
          </div>
        </div>
        <div className="text-center">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Projet complété à 100%</h3>
          <p className="text-sm text-gray-600 dark:text-gray-400">Toutes les étapes terminées avec succès</p>
        </div>
      </div>
    )
  }

  // Ajouter après le composant ProgressIndicator
  const InteractiveProgressBar = () => {
    // Exclure l'accueil du calcul de progression
    const totalSections = menuItems.filter((item) => item.id !== "home").length
    const visitedCount = visitedSections.size
    const progressPercentage = totalSections > 0 ? Math.round((visitedCount / totalSections) * 100) : 0

    return (
      <div className="w-full max-w-4xl mx-auto mb-8">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300">Exploration du projet</h3>
          <span className="text-sm font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            {progressPercentage}% complété
          </span>
        </div>

        <div className="relative">
          <div className="w-full h-3 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden shadow-inner">
            <div
              className="h-full bg-gradient-to-r from-blue-500 via-purple-500 to-blue-600 rounded-full transition-all duration-700 ease-out relative shadow-sm"
              style={{ width: `${progressPercentage}%` }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-pulse"></div>
            </div>
          </div>

          {/* Indicateurs de sections */}
          <div className="flex justify-between mt-2">
            {menuItems
              .filter((item) => item.id !== "home")
              .map((item, index) => (
                <div key={item.id} className="flex flex-col items-center">
                  <div
                    className={`w-2 h-2 rounded-full transition-all duration-300 shadow-sm ${
                      visitedSections.has(item.id)
                        ? "bg-gradient-to-r from-blue-500 to-purple-600 scale-125 shadow-blue-300 dark:shadow-blue-500"
                        : "bg-gray-300 dark:bg-gray-600"
                    }`}
                  />
                  <span className="text-xs text-gray-500 dark:text-gray-400 mt-1 text-center max-w-16 truncate">
                    {item.title.split(" - ")[1] || item.title}
                  </span>
                </div>
              ))}
          </div>
        </div>

        <div className="mt-3 text-center">
          <p className="text-xs text-gray-600 dark:text-gray-400">
            {visitedCount} sur {totalSections} sections explorées
          </p>
        </div>
      </div>
    )
  }

  const renderContent = () => {
    switch (activeSection) {
      case "home":
        return (
          <div className="space-y-8 animate-fade-in">
            <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-blue-50 via-purple-50 to-cyan-50 dark:from-blue-900/20 dark:via-purple-900/20 dark:to-cyan-900/20 p-8 md:p-12">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 via-purple-500/10 to-cyan-500/10" />
              <div className="relative">
                <Badge className="mb-4 bg-gradient-to-r from-blue-500 to-purple-600 text-white">
                  Projet Académique 2024
                </Badge>
                <h1 className="mb-4 text-4xl font-bold tracking-tight text-gray-900 md:text-6xl dark:text-gray-50">
                  Cloud Computing &{" "}
                  <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                    Virtualisation
                  </span>
                </h1>
                <p className="mb-8 max-w-2xl text-lg text-gray-600 dark:text-gray-400">
                  Une exploration approfondie des technologies cloud modernes avec AWS Educate et des solutions de
                  virtualisation avec Proxmox VE. Ce projet démontre la mise en œuvre pratique d'infrastructures cloud
                  et de systèmes virtualisés.
                </p>
                <div className="flex flex-wrap gap-4">
                  <Button
                    onClick={() => handleSectionChange("aws-intro")}
                    className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 transition-all duration-300"
                  >
                    <Cloud className="mr-2 h-4 w-4" />
                    Découvrir AWS
                  </Button>
                  <Button
                    onClick={() => handleSectionChange("proxmox-intro")}
                    variant="outline"
                    className="border-purple-200 hover:bg-purple-50 dark:border-purple-700 dark:hover:bg-purple-900/20 dark:text-purple-300 hover:text-purple-700 dark:hover:text-purple-200 transition-all duration-300"
                  >
                    <Server className="mr-2 h-4 w-4" />
                    Explorer Proxmox
                  </Button>
                </div>
              </div>
            </div>

            <ProgressIndicator />
            <InteractiveProgressBar />

            <div className="grid gap-6 md:grid-cols-2">
              <Card
                className="group cursor-pointer transition-all duration-300 hover:shadow-xl hover:-translate-y-1 dark:bg-gray-900 dark:border-gray-700"
                onClick={() => handleSectionChange("aws-intro")}
              >
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-orange-400 to-orange-600">
                      <Cloud className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <CardTitle className="text-xl dark:text-gray-50">Partie 1 - AWS Educate</CardTitle>
                      <CardDescription className="dark:text-gray-400">Cloud Computing Platform</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4 dark:text-gray-400">
                    Exploration des services AWS incluant EC2, S3, et la gestion d'infrastructures cloud scalables.
                  </p>
                  <div className="flex items-center text-sm text-blue-600 group-hover:text-blue-700 transition-colors">
                    Voir les détails{" "}
                    <ChevronRight className="ml-1 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  </div>
                </CardContent>
              </Card>

              <Card
                className="group cursor-pointer transition-all duration-300 hover:shadow-xl hover:-translate-y-1 dark:bg-gray-900 dark:border-gray-700"
                onClick={() => handleSectionChange("proxmox-intro")}
              >
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-purple-400 to-purple-600">
                      <Server className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <CardTitle className="text-xl dark:text-gray-50">Partie 2 - Proxmox VE</CardTitle>
                      <CardDescription className="dark:text-gray-400">Virtualisation Platform</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4 dark:text-gray-400">
                    Mise en place d'un environnement de virtualisation complet avec gestion des VMs et containers.
                  </p>
                  <div className="flex items-center text-sm text-purple-600 group-hover:text-purple-700 transition-colors">
                    Voir les détails{" "}
                    <ChevronRight className="ml-1 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="grid gap-4 md:grid-cols-3">
              <div className="flex items-center gap-3 rounded-lg border p-4 hover:bg-green-50 transition-colors duration-300 dark:border-gray-700 dark:hover:bg-green-900/10">
                <Shield className="h-8 w-8 text-green-500" />
                <div>
                  <h3 className="font-semibold dark:text-gray-50">Sécurité</h3>
                  <p className="text-sm text-muted-foreground dark:text-gray-400">Configurations sécurisées</p>
                </div>
              </div>
              <div className="flex items-center gap-3 rounded-lg border p-4 hover:bg-blue-50 transition-colors duration-300 dark:border-gray-700 dark:hover:bg-blue-900/10">
                <Database className="h-8 w-8 text-blue-500" />
                <div>
                  <h3 className="font-semibold dark:text-gray-50">Performance</h3>
                  <p className="text-sm text-muted-foreground dark:text-gray-400">Optimisation des ressources</p>
                </div>
              </div>
              <div className="flex items-center gap-3 rounded-lg border p-4 hover:bg-purple-50 transition-colors duration-300 dark:border-gray-700 dark:hover:bg-purple-900/10">
                <Zap className="h-8 w-8 text-purple-500" />
                <div>
                  <h3 className="font-semibold dark:text-gray-50">Scalabilité</h3>
                  <p className="text-sm text-muted-foreground dark:text-gray-400">Infrastructure évolutive</p>
                </div>
              </div>
            </div>
          </div>
        )

      case "aws-intro":
        return (
          <div className="space-y-6 animate-fade-in">
            <div className="rounded-2xl bg-gradient-to-r from-orange-50 to-orange-100 p-6 dark:from-orange-900/10 dark:to-orange-900/20">
              <div className="flex items-center gap-3 mb-4">
                <Cloud className="h-8 w-8 text-orange-600" />
                <h2 className="text-2xl font-bold text-orange-900 dark:text-orange-50">Introduction - AWS Educate</h2>
              </div>
              <p className="text-orange-800 leading-relaxed dark:text-orange-300">
                Amazon Web Services (AWS) Educate est une plateforme éducative qui fournit un accès gratuit aux services
                cloud d'Amazon. Dans cette partie du projet, nous avons exploré les services fondamentaux d'AWS,
                notamment EC2 pour le calcul, S3 pour le stockage, et les outils de gestion d'infrastructure.
              </p>
            </div>

            <div className="grid gap-6 md:grid-cols-2">
              <Card className="hover:shadow-lg transition-shadow duration-300 dark:bg-gray-900 dark:border-gray-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 dark:text-gray-50">
                    <Server className="h-5 w-5" />
                    Services Utilisés
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">EC2</Badge>
                    <span className="text-sm dark:text-gray-400">Instances de calcul virtuelles</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">S3</Badge>
                    <span className="text-sm dark:text-gray-400">Stockage d'objets scalable</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">VPC</Badge>
                    <span className="text-sm dark:text-gray-400">Réseau privé virtuel</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">IAM</Badge>
                    <span className="text-sm dark:text-gray-400">Gestion des identités</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow duration-300 dark:bg-gray-900 dark:border-gray-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 dark:text-gray-50">
                    <Zap className="h-5 w-5" />
                    Objectifs Réalisés
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-green-500" />
                    <span className="text-sm dark:text-gray-400">Déploiement d'instances EC2</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-green-500" />
                    <span className="text-sm dark:text-gray-400">Configuration de buckets S3</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-green-500" />
                    <span className="text-sm dark:text-gray-400">Mise en place de la sécurité</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-green-500" />
                    <span className="text-sm dark:text-gray-400">Monitoring et logs</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )

      case "aws-screenshots":
        return (
          <div className="space-y-6 animate-fade-in">
            <div className="flex items-center gap-3 mb-6">
              <ImageIcon className="h-8 w-8 text-blue-600" />
              <h2 className="text-2xl font-bold dark:text-gray-50">Captures d'écran - AWS</h2>
            </div>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {screenshots.slice(0, 3).map((screenshot) => (
                <Card
                  key={screenshot.id}
                  className="group cursor-pointer overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1 dark:bg-gray-900 dark:border-gray-700"
                  onClick={() => setSelectedImage(screenshot.url)}
                >
                  <div className="aspect-video overflow-hidden">
                    <img
                      src={screenshot.url || "/placeholder.svg"}
                      alt={screenshot.title}
                      className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-110"
                    />
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-semibold dark:text-gray-50">{screenshot.title}</h3>
                    <p className="text-sm text-muted-foreground mt-1 dark:text-gray-400">Cliquez pour agrandir</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )

      case "aws-problems":
        return (
          <div className="space-y-6 animate-fade-in">
            <div className="flex items-center gap-3 mb-6">
              <AlertTriangle className="h-8 w-8 text-amber-600 dark:text-amber-500" />
              <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-50">Problèmes Rencontrés - AWS</h2>
            </div>

            <div className="space-y-4">
              {problems.slice(0, 2).map((problem, index) => (
                <Card
                  key={index}
                  className="border-l-4 border-l-amber-500 hover:shadow-lg transition-shadow duration-300 dark:bg-gray-900 dark:border-gray-700"
                >
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg dark:text-gray-50">{problem.title}</CardTitle>
                      <Badge
                        variant={problem.severity === "high" ? "destructive" : "secondary"}
                        className={
                          problem.severity === "high"
                            ? "bg-red-500 text-white dark:bg-red-600 dark:text-white hover:bg-red-600 dark:hover:bg-red-700"
                            : ""
                        }
                      >
                        {problem.severity === "high" ? "Critique" : "Modéré"}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div>
                      <h4 className="font-semibold text-sm text-muted-foreground mb-1 dark:text-gray-400">
                        DESCRIPTION
                      </h4>
                      <p className="text-sm dark:text-gray-400">{problem.description}</p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-sm text-muted-foreground mb-1 dark:text-gray-400">SOLUTION</h4>
                      <p className="text-sm text-green-700 dark:text-green-300">{problem.solution}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )

      case "aws-report":
        return (
          <div className="space-y-6 animate-fade-in">
            <div className="flex items-center gap-3 mb-6">
              <FileText className="h-8 w-8 text-green-600" />
              <h2 className="text-2xl font-bold dark:text-gray-50">Rapport - AWS Educate</h2>
            </div>

            <Card className="p-6 hover:shadow-lg transition-shadow duration-300 dark:bg-gray-900 dark:border-gray-700">
              <div className="prose max-w-none dark:text-gray-400 dark:prose-invert">
                <h3 className="text-xl font-semibold mb-4 dark:text-gray-50">Synthèse du Projet AWS</h3>
                <p className="mb-4 leading-relaxed">
                  L'utilisation d'AWS Educate nous a permis de découvrir concrètement les services cloud d'Amazon. Le
                  projet s'est articulé autour de la création et de la gestion d'instances EC2, la configuration de
                  buckets S3 pour le stockage, et la mise en place d'une architecture réseau sécurisée.
                </p>

                <h4 className="text-lg font-semibold mb-3 dark:text-gray-50">Points Clés</h4>
                <ul className="space-y-2 mb-4">
                  <li className="flex items-start gap-2">
                    <div className="h-1.5 w-1.5 rounded-full bg-blue-500 mt-2" />
                    <span>Déploiement réussi de 3 instances EC2 avec différentes configurations</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="h-1.5 w-1.5 rounded-full bg-blue-500 mt-2" />
                    <span>Configuration de buckets S3 avec politiques de sécurité appropriées</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="h-1.5 w-1.5 rounded-full bg-blue-500 mt-2" />
                    <span>Mise en place d'un VPC avec sous-réseaux publics et privés</span>
                  </li>
                </ul>

                <h4 className="text-lg font-semibold mb-3 dark:text-gray-50">Apprentissages</h4>
                <p className="leading-relaxed">
                  Ce projet nous a permis de comprendre les concepts fondamentaux du cloud computing, notamment
                  l'élasticité, la scalabilité et la gestion des coûts. L'expérience pratique avec AWS a renforcé notre
                  compréhension des architectures distribuées et des bonnes pratiques de sécurité dans le cloud.
                </p>
              </div>
            </Card>
          </div>
        )

      case "proxmox-intro":
        return (
          <div className="space-y-6 animate-fade-in">
            <div className="rounded-2xl bg-gradient-to-r from-purple-50 to-purple-100 p-6 dark:from-purple-900/10 dark:to-purple-900/20">
              <div className="flex items-center gap-3 mb-4">
                <Server className="h-8 w-8 text-purple-600" />
                <h2 className="text-2xl font-bold text-purple-900 dark:text-purple-50">Introduction - Proxmox VE</h2>
              </div>
              <p className="text-purple-800 leading-relaxed dark:text-purple-300">
                Proxmox Virtual Environment (VE) est une plateforme de virtualisation open-source qui combine la
                virtualisation KVM et la containerisation LXC. Dans cette partie, nous avons exploré la création et la
                gestion de machines virtuelles, la configuration réseau avancée, et les fonctionnalités de haute
                disponibilité.
              </p>
            </div>

            <div className="grid gap-6 md:grid-cols-2">
              <Card className="hover:shadow-lg transition-shadow duration-300 dark:bg-gray-900 dark:border-gray-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 dark:text-gray-50">
                    <Database className="h-5 w-5" />
                    Technologies Explorées
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">KVM</Badge>
                    <span className="text-sm dark:text-gray-400">Virtualisation complète</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">LXC</Badge>
                    <span className="text-sm dark:text-gray-400">Virtualisation complète</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">LXC</Badge>
                    <span className="text-sm dark:text-gray-400">Containers Linux</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">ZFS</Badge>
                    <span className="text-sm dark:text-gray-400">Système de fichiers avancé</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">Ceph</Badge>
                    <span className="text-sm dark:text-gray-400">Stockage distribué</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow duration-300 dark:bg-gray-900 dark:border-gray-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 dark:text-gray-50">
                    <Shield className="h-5 w-5" />
                    Réalisations
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-purple-500" />
                    <span className="text-sm dark:text-gray-400">Installation et configuration Proxmox</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-purple-500" />
                    <span className="text-sm dark:text-gray-400">Création de VMs Linux et Windows</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-purple-500" />
                    <span className="text-sm dark:text-gray-400">Configuration réseau avancée</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-purple-500" />
                    <span className="text-sm dark:text-gray-400">Sauvegarde et restauration</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )

      case "proxmox-screenshots":
        return (
          <div className="space-y-6 animate-fade-in">
            <div className="flex items-center gap-3 mb-6">
              <ImageIcon className="h-8 w-8 text-purple-600" />
              <h2 className="text-2xl font-bold dark:text-gray-50">Captures d'écran - Proxmox</h2>
            </div>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {screenshots.slice(3, 6).map((screenshot) => (
                <Card
                  key={screenshot.id}
                  className="group cursor-pointer overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1 dark:bg-gray-900 dark:border-gray-700"
                  onClick={() => setSelectedImage(screenshot.url)}
                >
                  <div className="aspect-video overflow-hidden">
                    <img
                      src={screenshot.url || "/placeholder.svg"}
                      alt={screenshot.title}
                      className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-110"
                    />
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-semibold dark:text-gray-50">{screenshot.title}</h3>
                    <p className="text-sm text-muted-foreground mt-1 dark:text-gray-400">Cliquez pour agrandir</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )

      case "proxmox-problems":
        return (
          <div className="space-y-6 animate-fade-in">
            <div className="flex items-center gap-3 mb-6">
              <AlertTriangle className="h-8 w-8 text-amber-600 dark:text-amber-500" />
              <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-50">Problèmes Rencontrés - Proxmox</h2>
            </div>

            <div className="space-y-4">
              {problems.slice(2, 3).map((problem, index) => (
                <Card
                  key={index}
                  className="border-l-4 border-l-amber-500 hover:shadow-lg transition-shadow duration-300 dark:bg-gray-900 dark:border-gray-700"
                >
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg dark:text-gray-50">{problem.title}</CardTitle>
                      <Badge
                        variant={problem.severity === "high" ? "destructive" : "secondary"}
                        className={
                          problem.severity === "high"
                            ? "bg-red-500 text-white dark:bg-red-600 dark:text-white hover:bg-red-600 dark:hover:bg-red-700"
                            : ""
                        }
                      >
                        {problem.severity === "high" ? "Critique" : "Modéré"}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div>
                      <h4 className="font-semibold text-sm text-muted-foreground mb-1 dark:text-gray-400">
                        DESCRIPTION
                      </h4>
                      <p className="text-sm dark:text-gray-400">{problem.description}</p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-sm text-muted-foreground mb-1 dark:text-gray-400">SOLUTION</h4>
                      <p className="text-sm text-green-700 dark:text-green-300">{problem.solution}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )

      case "proxmox-report":
        return (
          <div className="space-y-6 animate-fade-in">
            <div className="flex items-center gap-3 mb-6">
              <FileText className="h-8 w-8 text-purple-600" />
              <h2 className="text-2xl font-bold dark:text-gray-50">Rapport - Proxmox VE</h2>
            </div>

            <Card className="p-6 hover:shadow-lg transition-shadow duration-300 dark:bg-gray-900 dark:border-gray-700">
              <div className="prose max-w-none dark:text-gray-400 dark:prose-invert">
                <h3 className="text-xl font-semibold mb-4 dark:text-gray-50">Synthèse du Projet Proxmox</h3>
                <p className="mb-4 leading-relaxed">
                  L'implémentation de Proxmox VE nous a offert une perspective complète sur la virtualisation
                  d'entreprise. Le projet a couvert l'installation, la configuration, et la gestion d'un environnement
                  virtualisé complet avec des fonctionnalités avancées de stockage et de réseau.
                </p>

                <h4 className="text-lg font-semibold mb-3 dark:text-gray-50">Réalisations Techniques</h4>
                <ul className="space-y-2 mb-4">
                  <li className="flex items-start gap-2">
                    <div className="h-1.5 w-1.5 rounded-full bg-purple-500 mt-2" />
                    <span>Installation complète de Proxmox VE sur serveur dédié</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="h-1.5 w-1.5 rounded-full bg-purple-500 mt-2" />
                    <span>Création et gestion de 5 VMs avec différents OS</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="h-1.5 w-1.5 rounded-full bg-purple-500 mt-2" />
                    <span>Configuration de pools de stockage ZFS</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="h-1.5 w-1.5 rounded-full bg-purple-500 mt-2" />
                    <span>Mise en place de sauvegardes automatisées</span>
                  </li>
                </ul>

                <h4 className="text-lg font-semibold mb-3 dark:text-gray-50">Impact Pédagogique</h4>
                <p className="leading-relaxed">
                  Cette expérience avec Proxmox a considérablement enrichi notre compréhension de la virtualisation
                  d'entreprise. Nous avons acquis des compétences pratiques en administration système, gestion des
                  ressources, et planification de la capacité. La comparaison avec AWS nous a également permis
                  d'apprécier les différences entre solutions cloud publiques et infrastructures on-premise.
                </p>
              </div>
            </Card>
          </div>
        )

      case "conclusion":
        return (
          <div className="space-y-6 animate-fade-in">
            <div className="rounded-2xl bg-gradient-to-r from-green-50 to-emerald-100 p-6 dark:from-green-900/10 dark:to-emerald-900/20">
              <div className="flex items-center gap-3 mb-4">
                <ChevronRight className="h-8 w-8 text-green-600" />
                <h2 className="text-2xl font-bold text-green-900 dark:text-green-50">Conclusion du Projet</h2>
              </div>
              <p className="text-green-800 leading-relaxed dark:text-green-300">
                Ce projet nous a permis d'explorer deux approches complémentaires de l'infrastructure IT moderne : le
                cloud computing avec AWS et la virtualisation on-premise avec Proxmox VE.
              </p>
            </div>

            <div className="grid gap-6 md:grid-cols-2">
              <Card className="hover:shadow-lg transition-shadow duration-300 dark:bg-gray-900 dark:border-gray-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-green-700 dark:text-green-300">
                    <Zap className="h-5 w-5" />
                    Compétences Acquises
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-green-500" />
                    <span className="text-sm dark:text-gray-400">Administration cloud AWS</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-green-500" />
                    <span className="text-sm dark:text-gray-400">Virtualisation avec Proxmox</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-green-500" />
                    <span className="text-sm dark:text-gray-400">Configuration réseau avancée</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-green-500" />
                    <span className="text-sm dark:text-gray-400">Sécurité et bonnes pratiques</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow duration-300 dark:bg-gray-900 dark:border-gray-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-blue-700 dark:text-blue-300">
                    <Shield className="h-5 w-5" />
                    Perspectives d'Avenir
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-blue-500" />
                    <span className="text-sm dark:text-gray-400">Architecture hybride cloud</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-blue-500" />
                    <span className="text-sm dark:text-gray-400">Automatisation DevOps</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-blue-500" />
                    <span className="text-sm dark:text-gray-400">Containers et Kubernetes</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-blue-500" />
                    <span className="text-sm dark:text-gray-400">Monitoring et observabilité</span>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="p-6 bg-gradient-to-r from-blue-50 to-purple-50 hover:shadow-lg transition-shadow duration-300 dark:from-blue-900/10 dark:to-purple-900/10 dark:bg-gray-900 dark:border-gray-700">
              <h3 className="text-xl font-semibold mb-4 dark:text-gray-50">Bilan Global</h3>
              <p className="leading-relaxed text-gray-700 dark:text-gray-400">
                L'expérience combinée d'AWS et Proxmox nous a donné une vision complète des enjeux actuels de
                l'infrastructure IT. Nous avons pu comparer les avantages du cloud public (scalabilité, facilité de
                déploiement) avec ceux de la virtualisation on-premise (contrôle, performance, coûts). Cette double
                approche nous prépare efficacement aux défis technologiques futurs et nous donne les bases nécessaires
                pour concevoir des architectures IT modernes et adaptées aux besoins spécifiques de chaque organisation.
              </p>
            </Card>
          </div>
        )

      default:
        return <div>Section non trouvée</div>
    }
  }

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50 dark:from-slate-900 dark:via-blue-900 dark:to-purple-900 text-gray-900 dark:text-gray-50">
        <AppSidebar />
        <main className="flex-1 overflow-auto">
          <div className="sticky top-0 z-10 border-b bg-white/80 backdrop-blur-sm dark:bg-gray-900/80 dark:border-gray-800">
            <div className="flex h-16 items-center justify-between px-6">
              <div className="flex items-center gap-4">
                <SidebarTrigger />
                <div className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
                  <span className="text-sm font-medium dark:text-gray-50">Projet en ligne</span>
                </div>
              </div>

              <div className="flex items-center gap-3">
                {/* Theme Toggle Button */}
                <button
                  onClick={toggleTheme}
                  className="flex h-10 w-10 items-center justify-center rounded-full bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 transition-all duration-300 hover:bg-gray-200 dark:hover:bg-gray-700 hover:scale-105 border border-gray-200 dark:border-gray-600"
                  title={isDarkMode ? "Passer en mode clair" : "Passer en mode sombre"}
                >
                  {isDarkMode ? (
                    <Sun className="h-5 w-5 transition-transform duration-300 rotate-0 hover:rotate-12" />
                  ) : (
                    <Moon className="h-5 w-5 transition-transform duration-300 rotate-0 hover:-rotate-12" />
                  )}
                </button>

                {/* Profile Dropdown */}
                <div className="relative">
                  <button
                    onClick={() => setIsProfileOpen(!isProfileOpen)}
                    className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-blue-500 to-purple-600 text-white transition-all duration-300 hover:shadow-lg hover:scale-105"
                  >
                    <User className="h-5 w-5" />
                  </button>

                  {isProfileOpen && (
                    <>
                      {/* Overlay */}
                      <div className="fixed inset-0 z-10" onClick={() => setIsProfileOpen(false)} />

                      {/* Dropdown Panel */}
                      <div className="absolute right-0 top-12 z-20 w-80 rounded-xl bg-white/95 backdrop-blur-sm border border-gray-200 shadow-2xl animate-fade-in dark:bg-gray-900/95 dark:border-gray-700">
                        <div className="p-6">
                          <div className="flex items-center gap-3 mb-4 pb-4 border-b border-gray-100 dark:border-gray-700">
                            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-blue-500 to-purple-600 shadow-lg">
                              <Users className="h-6 w-6 text-white" />
                            </div>
                            <div>
                              <h3 className="font-semibold text-lg text-gray-900 dark:text-gray-50">
                                Informations du Groupe
                              </h3>
                              <p className="text-sm text-gray-500 dark:text-gray-400">Projet Cloud Computing</p>
                            </div>
                          </div>

                          <div className="space-y-3 mb-4">
                            <h4 className="font-medium text-gray-700 text-sm uppercase tracking-wide dark:text-gray-300">
                              Membres du groupe
                            </h4>

                            <div className="flex items-center gap-3 p-2 rounded-lg hover:bg-blue-50 transition-colors dark:hover:bg-blue-900/20 border border-transparent hover:border-blue-200 dark:hover:border-blue-800">
                              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-yellow-400 to-orange-500 shadow-sm">
                                <Crown className="h-4 w-4 text-white" />
                              </div>
                              <div>
                                <p className="font-medium text-gray-900 dark:text-gray-50">Baouissila Beni</p>
                                <p className="text-xs text-gray-500 dark:text-gray-400">Chef de groupe</p>
                              </div>
                            </div>

                            <div className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 transition-colors dark:hover:bg-gray-800/20 border border-transparent hover:border-gray-200 dark:hover:border-gray-700">
                              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-blue-400 to-blue-600 shadow-sm">
                                <User className="h-4 w-4 text-white" />
                              </div>
                              <p className="font-medium text-gray-900 dark:text-gray-50">Moctar DAFF</p>
                            </div>

                            <div className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 transition-colors dark:hover:bg-gray-800/20 border border-transparent hover:border-gray-200 dark:hover:border-gray-700">
                              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-pink-400 to-pink-600 shadow-sm">
                                <User className="h-4 w-4 text-white" />
                              </div>
                              <p className="font-medium text-gray-900 dark:text-gray-50">Sokhna Isseu NDEYE</p>
                            </div>

                            <div className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 transition-colors dark:hover:bg-gray-800/20 border border-transparent hover:border-gray-200 dark:hover:border-gray-700">
                              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-green-400 to-green-600 shadow-sm">
                                <User className="h-4 w-4 text-white" />
                              </div>
                              <p className="font-medium text-gray-900 dark:text-gray-50">Claine Pascal BOULOUDI</p>
                            </div>

                            <div className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 transition-colors dark:hover:bg-gray-800/20 border border-transparent hover:border-gray-200 dark:hover:border-gray-700">
                              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-purple-400 to-purple-600 shadow-sm">
                                <User className="h-4 w-4 text-white" />
                              </div>
                              <p className="font-medium text-gray-900 dark:text-gray-50">Leuz DIALLO</p>
                            </div>
                          </div>

                          <div className="pt-4 border-t border-gray-100 dark:border-gray-700">
                            <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                              <FileText className="h-4 w-4" />
                              <span>
                                <strong className="text-gray-800 dark:text-gray-200">Projet adressé à :</strong>{" "}
                                Monsieur Soumaré
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="p-6">{renderContent()}</div>
        </main>
      </div>

      {selectedImage && (
        <ImageModal
          src={selectedImage || "/placeholder.svg"}
          title="Capture d'écran"
          onClose={() => setSelectedImage(null)}
        />
      )}
    </SidebarProvider>
  )
}
